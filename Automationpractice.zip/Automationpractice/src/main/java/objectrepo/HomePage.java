package objectrepo;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage{
	public WebDriver driver;
	public WebDriverWait wd;
	@FindBy(xpath="//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")
	WebElement SignIn;
	
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
		wd=new WebDriverWait(driver,30);
		//This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}
	

	public void goToLoginPage()
	{

		wd.until(ExpectedConditions.visibilityOf(this.SignIn));
		this.SignIn.click();
	}

	
}
