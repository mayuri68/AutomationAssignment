package tests;

import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;

import objectrepo.HomePage;
import objectrepo.LoginPage;
import objectrepo.ProductCheckout;
import operations.BrowserInitialization;
import operations.ScreenShots;


public class ProductSelection {
	WebDriver driver;
	HomePage hp;
	LoginPage lp;
	ProductCheckout acc;
	int i = 0;
	
	@Parameters({"URL"})
	@BeforeTest
	 public void browserlaunch(String URL)
     {
                    driver = BrowserInitialization.StartBrowser(URL);
                    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
                    hp = new HomePage(driver);
                    lp = new LoginPage(driver);
                    acc = new ProductCheckout(driver);
     }
                    
	

	@Parameters({"username","password"})
	@Test(priority=1)
	public void signIntoWebsite(String username,String password) throws InterruptedException, TimeoutException
	{
		hp.goToLoginPage();
		lp.Login(username, password);
		
		//Verify if navigation is done to my account
		Assert.assertEquals(driver.getTitle(), "My account - My Store");
	}
	
	
	@Test(priority=2)
	public void selectTshirt() throws InterruptedException 
	{
		//Choose category
		acc.categorytSelection();
		Assert.assertTrue(acc.confirmationMessage().contains("Product successfully added to your shopping cart"));
		
		Assert.assertTrue(acc.shirtInformation().contains("Faded Short Sleeve T-shirts"));
		
		Assert.assertTrue(acc.colorInformation().contains("Orange, S"));
		
		Assert.assertTrue(acc.priceInformation().contains("Total"));
		Assert.assertTrue(acc.priceInformation().contains("$16.51"));
		
		Assert.assertTrue(acc.quantityInformation().contains("Quantity"));
		Assert.assertTrue(acc.quantityInformation().contains("1"));
		
		
       acc.proceedToCheckout();
	}
	
	// Taking Screen shot on test fail
    @AfterMethod
    public void screenshot(ITestResult result)
    {
               i = i+1;
               String name = "ScreenShot";
               String x = name+String.valueOf(i);
              if(ITestResult.FAILURE == result.getStatus())
                {
                               ScreenShots.captureScreenShot(driver, x);
                 }
}
	
	@AfterTest
	public void closeBrowser() 
	{
        driver.quit();
	}

}
