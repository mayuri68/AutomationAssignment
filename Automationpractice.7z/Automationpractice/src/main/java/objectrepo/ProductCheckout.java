package objectrepo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductCheckout{
	public WebDriver driver;
	public WebDriverWait wd;
	
	@FindBy(xpath="//*[@id=\"block_top_menu\"]/ul/li[3]/a")
	WebElement tshirts;
	@FindBy(css="a.product_img_link[title='Faded Short Sleeve T-shirts']")
	WebElement product;
	@FindBy(xpath="//*[@id=\"add_to_cart\"]/button")
	WebElement addToCart;
	
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[1]/h2")
	WebElement confirmationMsg;
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[1]/div[2]/span[contains(@class,'product-name')]")
	WebElement shirtInfo;
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[1]/div[2]/span[contains(@id,'layer_cart_product_attributes')]")
	WebElement colorInfo;
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[1]/div[2]/div[1]")
	WebElement quantityInfo;
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[1]/div[2]/div[2]")
	WebElement priceInfo;
	
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a")
	WebElement checkout;
	
	public ProductCheckout(WebDriver driver)
	{
		this.driver=driver;
		wd=new WebDriverWait(driver,30);
		//This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}
	

	
	public void categorytSelection()
	{
		
		wd.until(ExpectedConditions.visibilityOf(this.tshirts));
		this.tshirts.click();
		
		wd.until(ExpectedConditions.visibilityOf(this.product));
		//this.product.click();
		Actions builder=new Actions(driver);
		Action mouseOverHome = builder.moveToElement(product).doubleClick().build();
		mouseOverHome.perform();
		//Add to cart
		this.addToCart.click();
		
		wd.until(ExpectedConditions.visibilityOf(this.shirtInfo));        

	}
	
	public String confirmationMessage() {
		return this.confirmationMsg.getAttribute("textContent");
	}
	
	public String shirtInformation() {
		return this.shirtInfo.getAttribute("textContent");
	}
	
	public String colorInformation() {
		return this.colorInfo.getAttribute("textContent");
	}
	
	public String quantityInformation() {
		return this.quantityInfo.getAttribute("textContent");
	}
	
	public String priceInformation() {
		return this.priceInfo.getAttribute("textContent");
	}

    public void proceedToCheckout() {
    	this.checkout.click();
    }

}

