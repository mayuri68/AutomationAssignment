package objectrepo;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage{
	public WebDriver driver;
	public WebDriverWait wd;

	@FindBy(id="email")
	WebElement username;
	@FindBy(id="passwd")
	WebElement password;
	@FindBy(id="SubmitLogin")
	WebElement login;
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
		wd=new WebDriverWait(driver,30);
		//This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}
	

	public void Login(String user,String password)
	{
        
		wd.until(ExpectedConditions.visibilityOf(this.username));
		this.username.sendKeys(user);
		wd.until(ExpectedConditions.visibilityOf(this.password));
		this.password.sendKeys(password);
		this.login.click();
	}

	
}
